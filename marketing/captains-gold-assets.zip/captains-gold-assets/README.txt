CAPTAIN'S GOLD — GAME ASSETS
Prepared: 28 October 2026

Game: https://vadimbrainshell-sketch.github.io/captains-gold/
Game ID: thc1-awf

26 original-resolution PNG assets from the current game artwork. Existing transparency is preserved. No image upscaling, redrawing or lossy compression has been applied.

CONTENTS
01-brand: main treasure chest artwork with the game title baked in. A separate editable/vector logo is not included.
02-backgrounds: cabin foreground and ocean background. Layer the cabin over the ocean to fill the transparent windows.
03-props-and-frame: lantern and copper reel frame.
04-symbols: regular reel symbols.
05-coins: gold and black collector coins, four jackpot coins, bonus skull.
06-jackpot-titles: MINI, MINOR, MAJOR and GRAND title artwork.

Open index.html for a visual asset browser. manifest.csv lists native dimensions and file sizes.

This pack contains source artwork for promotional layouts, not finished advertising banners. Runtime glows, animated effects and dynamically rendered coin amounts are not baked into the PNGs. Older concept artwork, obsolete screenshots, audio, fonts, source code and RGS configuration are not included.
